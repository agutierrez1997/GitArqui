Los archivos dentro de esta carpeta se encuentran 3 archivos: bblayers.conf y local.conf van dentro de la carpeta de conf, que a su vez está dentro de la carpeta de built. 
El archivo faltante, el bitbake.conf, se encuentra dentro de la carpeta conf, que a su vez está en la carpeta meta, ubicada en dentro de la carpeta del poky-warrior, al igual que la carpeta built mencionada en el primer párrafo

