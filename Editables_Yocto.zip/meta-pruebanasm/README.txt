La carpeta llamada "meta-pruebanasm" se debe ubicar dentro de la carpeta del poky-warrior.
